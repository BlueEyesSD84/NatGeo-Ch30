# NatGeo-Ch30
This is for FSDI 102 Class 1 Replication of the Nat Geo Website
we learned how to clone a repo from github

